var pink = document.getElementById('pink');
var orange = document.getElementById('orange');
var cornflowerblue = document.getElementById('cornflowerblue');
var purple = document.getElementById('purple');
// skin change btn
var topnav = document.getElementById('topnav');
var slctlist = document.getElementById('slctlist');
var famoussite = document.getElementById('famoussite');
var speciallink1 = document.getElementById('speciallink1');
var speciallink2 = document.getElementById('speciallink2');
var speciallink3 = document.getElementById('speciallink3');
var speciallink4 = document.getElementById('speciallink4');
var speciallink5 = document.getElementById('speciallink5');
var speciallink6 = document.getElementById('speciallink6');
// skin element

function toPink() {
    topnav.style.borderTop = '2px solid pink';
    slctlist.style.background = 'pink';
    famoussite.style.border = '1px solid pink';
    speciallink1.style.color = 'pink';
    speciallink2.style.color = 'pink';
    speciallink3.style.color = 'pink';
    speciallink4.style.color = 'pink';
    speciallink5.style.color = 'pink';
    speciallink6.style.color = 'pink';
}

function toOrange() {
    topnav.style.borderTop = '2px solid orange';
    slctlist.style.background = 'orange';
    famoussite.style.border = '1px solid orange';
    speciallink1.style.color = 'orange';
    speciallink2.style.color = 'orange';
    speciallink3.style.color = 'orange';
    speciallink4.style.color = 'orange';
    speciallink5.style.color = 'orange';
    speciallink6.style.color = 'orange';
}

function toCornflowerblue() {
    topnav.style.borderTop = '2px solid cornflowerblue';
    slctlist.style.background = 'cornflowerblue';
    famoussite.style.border = '1px solid cornflowerblue';
    speciallink1.style.color = 'cornflowerblue';
    speciallink2.style.color = 'cornflowerblue';
    speciallink3.style.color = 'cornflowerblue';
    speciallink4.style.color = 'cornflowerblue';
    speciallink5.style.color = 'cornflowerblue';
    speciallink6.style.color = 'cornflowerblue';
}

function toPurple() {
    topnav.style.borderTop = '2px solid purple';
    slctlist.style.background = 'purple';
    famoussite.style.border = '1px solid purple';
    speciallink1.style.color = 'purple';
    speciallink2.style.color = 'purple';
    speciallink3.style.color = 'purple';
    speciallink4.style.color = 'purple';
    speciallink5.style.color = 'purple';
    speciallink6.style.color = 'purple';
}
